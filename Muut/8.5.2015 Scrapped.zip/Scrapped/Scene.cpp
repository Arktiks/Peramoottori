#include "Scene.h"
#include "graphics\SpriteBatch.h"
#include "graphics\RenderSystem.h"


pm::Scene::Scene()
{
	
}

void pm::Scene::Update()
{

}                   

void pm::Scene::Draw()
{
	// RenderSystemille kerro shader
	
	// kuhtu sprite p�tsi�
}