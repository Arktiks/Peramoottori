#include "Atlas.h"
using namespace pm;
Atlas::Atlas(std::string fileName)
{
	createTexture(fileName);
}
Atlas::~Atlas()
{

}