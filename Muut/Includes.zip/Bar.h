#pragma once

class Bar
{
public:
	Bar();
	~Bar();
};