#ifndef DEBUG_TOOLS
#define DEBUG_TOOLS

#include <cstdio>
#include <string>
#include <iostream>

#define DEBUG(text) Debug::printSomething text

#define NEW new(__FILE__, __LINE__)

extern void* operator new(size_t size, const char* file, int line);
extern void* operator new[](size_t size, const char* file, int line);
extern void operator delete(void* ptr);
extern void operator delete[](void* ptr);

//#include "NewOverload.h"


class Debug
{
public:
	static void printSomething(char* asd, ...);

	Debug();
	~Debug();
};

#endif