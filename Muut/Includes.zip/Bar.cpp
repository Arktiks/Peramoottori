#include "Bar.h"
#include "Debug.h"

Bar::Bar()
{
	float* asd = new float(12.2f);
	DEBUG(("asda"));
}

Bar::~Bar()
{
}