#include "Foo.h"

Foo::Foo()
{
}

Foo::~Foo()
{
}