#ifndef OVERLOAD_NEW
#define OVERLOAD_NEW

#include <cstdio>

void* operator new (size_t size)
{
	void* ptr = new char[size]; // Make void* pointer based on size.
	printf("custom new");
	return ptr; // Return pointer as per normal.
}

#endif