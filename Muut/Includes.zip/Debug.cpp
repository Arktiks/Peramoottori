#include "Debug.h"

#include <cstdlib>
#include <stdarg.h>

void* operator new (size_t size, const char* file, int line)
{
	void* ptr = new char[size]; // Make void* pointer based on size.
	printf("custom new");
	return ptr; // Return pointer as per normal.
}

void *operator new[](size_t size, const char* file, int line)
{
	return operator new(size); // Use above function.
}

void operator delete(void* ptr)
{
	free(ptr); // Free pointer as per normal.
}

void operator delete[](void* ptr)
{
	operator delete(ptr);
}

void Debug::printSomething(char* asd, ...)
{

	va_list args;
	va_start(args, asd);
	vprintf(asd, args);
	va_end(args);

	//std::cout << "this is something: " << asd << std::endl;
}

Debug::Debug()
{
}

Debug::~Debug()
{
}