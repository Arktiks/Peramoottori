#pragma once
#include "Debug.h"

class Foo
{
public:
	Foo();
	~Foo();
};