#include "Foo.h"
#include <Windows.h>
#include "Bar.h"


int main()
{
	DEBUG(("asd"));
	int* a = NEW int(2);

	DEBUG(("tama on debug: %i %s kaksi argumenttia", *a, "hei"));

	delete a;

	system("pause");
	return 0;
}